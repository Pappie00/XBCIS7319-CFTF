<?php
session_start();
$connect = mysqli_connect("localhost", "root", "", "cftf");

if(isset($_GET['id']) && $_GET['id']!=''){
	$image_required='';
	$id=get_safe_value($conn,$_GET['id']);
	$res=mysqli_query($conn,"select * from vehicle where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$vin=$row['vin'];
    	$make=$row['make'];
    	$model=$row['model'];
    	$year=$row['year'];
    	$exteriorColour=$row['exteriorColour'];
    	$interiorColour=$row['interiorColour'];
		$options=$row['options'];
		$price=$row['price'];
		$sellPrice=$row['sellPrice'];
        $category=$row['category'];
	}else{
		header('location:CarList.php');
		die();
	}
}
?>
<!DOCTYPE html>
<html lang="zxx">
        <head>
            <title>CFTF-Website</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta charset="utf-8">
            <!-- External CSS libraries -->
            <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
            <link rel="stylesheet" type="text/css" href="assets/css/animate.min.css">
            <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-submenu.css">
            <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-select.min.css">
            <link rel="stylesheet" type="text/css" href="assets/css/magnific-popup.css">
            <link rel="stylesheet" href="assets/css/leaflet.css" type="text/css">
            <link rel="stylesheet" href="assets/css/map.css" type="text/css">
            <link rel="stylesheet" type="text/css" href="assets/fonts/font-awesome/css/font-awesome.min.css">
            <link type="text/css" rel="stylesheet" href="assets/fonts/bootstrap-icons/bootstrap-icons.css">
            <link rel="stylesheet" type="text/css" href="assets/fonts/flaticon/font/flaticon.css">
            <link rel="stylesheet" type="text/css" href="assets/fonts/linearicons/style.css">
            <link rel="stylesheet" type="text/css"  href="assets/css/jquery.mCustomScrollbar.css">
            <link rel="stylesheet" type="text/css"  href="assets/css/dropzone.css">
            <link rel="stylesheet" type="text/css"  href="assets/css/lightbox.min.css">
            <link rel="stylesheet" type="text/css"  href="assets/css/jnoty.css">
            <link rel="stylesheet" type="text/css"  href="assets/css/slick.css">
            <!-- Custom stylesheet -->
            <link rel="stylesheet" type="text/css" href="assets/css/initial.css">
            <link rel="stylesheet" type="text/css" href="assets/css/detail_style.css">
            <link rel="stylesheet" type="text/css" id="style_sheet" href="assets/css/skins/midnight-blue.css">
            <link href="https://fonts.googleapis.com/css2?family=Poppinsd:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
        </head>
        <body>
        <div class="container">
            <div class="navbar">
                <img src="assets/img/logo-bl.png" class="logo">
                <nav>
                <ul>
                    <li><a href="index.html">HOME</a></li>
                    <li><a href="CarList.php">CATALOGUE</a></li>
                    <li><a href="Enquire_Contact.html">ENQUIRE</a></li>
                </ul>
                </nav>
            </div>
        <?php
        $query = "SELECT * FROM vehicle";
        $result = mysqli_query($connect, $query);
        if(mysqli_num_rows($result) > 0)
        {
            while($row = mysqli_fetch_array($result))
            {
                ?>
        <div class="page_loader"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-12 col-xs-12">
                        <div class="car-details-section">
                            <div class="cardetailsslider-2 mb-40">
                                <div class="main clearfix">
                                    <div class="slider slider-fors">
                                        <div class="slider-slider-for-photo">
                                            <!-- <img src="assets/img/car/car-5.png" class="img-fluid w-100" alt="slider-car"> -->
                                            <?php  echo "<img class='img-fluid w-100' src='Dashboard/".$row['image']."' />"; ?>
                                        </div>
                                    </div>

                                    <div class="heading-car-2">
                                        <div class="pull-left">
                                            <h3><?php echo $row["make"] ?></h3>
                                            <h4><?php echo $row["model"] ?></h4>
                                        </div>
                                        <div class="pull-right">
                                            <div class="price-box-3"><h3>$<?php echo $row["sellPrice"] ?></h3><span></span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tabbing tabbing-box mb-40">
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                        <div class="accordion accordion-flush" id="accordionFlushExample">
                                            <div class="accordion-item">
                                                <div class="car-description mb-50">
                                                    <h3 class="heading-2">
                                                        Description
                                                    </h3>
                                                    <p><?php echo $row["options"] ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="sidebar-right">
                            <div class="widget advanced-search d-none d-xl-block d-lg-block">
                                <h3 class="sidebar-title">About This Car</h3>
                                <ul>
                                    <li>
                                        <span>Make</span><?php echo $row["make"] ?>
                                    </li>
                                    <li>
                                        <span>Model</span><?php echo $row["model"] ?>
                                    </li>
                                    <li>
                                        <span>Body Style</span><?php echo $row["category"] ?>
                                    </li>
                                    <li>
                                        <span>Year</span><?php echo $row["year"] ?>
                                    </li>
                                    <li>
                                        <span>Exterior Color</span><?php echo $row["exteriorColour"] ?>
                                    </li>
                                    <li>
                                        <span>Interior Color</span><?php echo $row["interiorColour"] ?>
                                    </li>
                                    <button type="button"><a href="download.php?image=<?php echo $row['quoteFile']?>">Get A Quote</a></button>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
            }
        }
        ?>
            <script src="assets/js/jquery.min.js"></script>
            <script src="jassets/s/popper.min.js"></script>
            <script src="assets/js/bootstrap.bundle.min.js"></script>
            <script  src="assets/js/bootstrap-submenu.js"></script>
            <script  src="assets/js/rangeslider.js"></script>
            <script  src="assets/js/jquery.mb.YTPlayer.js"></script>
            <script  src="assets/js/bootstrap-select.min.js"></script>
            <script  src="assets/js/jquery.easing.1.3.js"></script>
            <script  src="assets/js/jquery.scrollUp.js"></script>
            <script  src="assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
            <script  src="assets/js/dropzone.js"></script>
            <script  src="assets/js/slick.min.js"></script>
            <script  src="assets/js/slick.min.js"></script>
            <script  src="assets/js/app.js"></script>
            <script  src="assets/js/ie10-viewport-bug-workaround.js"></script>
        </body>
</html>
