<?php
session_start();
$connect = mysqli_connect("localhost", "root", "", "cftf");
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Congo Fast Forwarder and Trade Services</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="utf-8">
        <style>
            #foo {width: 100%;height: 100%;}
        </style>
        <!-- External CSS libraries -->
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="assets/css/animate.min.css">
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-submenu.css">
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap-select.min.css">
        <link rel="stylesheet" type="text/css"  href="assets/css/jquery.mCustomScrollbar.css">
        <link rel="stylesheet" type="text/css"  href="assets/css/dropzone.css">
          <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Custom stylesheet -->
        <link rel="stylesheet" type="text/css" href="assets/css/initial.css">
        <link rel="stylesheet" type="text/css" href="assets/css/Catalog_style.css">
        <link rel="stylesheet" type="text/css" id="style_sheet" href="assets/css/skins/midnight-blue.css">
        <link href="https://fonts.googleapis.com/css2?family=Poppinsd:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="assets/css/ie10-viewport-bug-workaround.css">
        <script  src="assets/js/ie-emulation-modes-warning.js"></script>
    </head>
    <body>
    <div class="page_loader"></div>
    <body>
        <div class="container">
            <div class="navbar">
            <img src="assets/images/logo-bl.png" class="logo">
            <nav>
                <ul>
                    <li><a href="index.html">HOME</a></li>
                    <li><a href="CarList.php">CATALOGUE</a></li>
                    <li><a href="Enquire_Contact.html">ENQUIRE</a></li>
                </ul>
            </nav>
            </div>
            <div class="featured-car content-area">
                <div class="container">
                    <div class="row">
                        <h2 class="center">Current cars in stock</h2>
                        <hr> 
                            <?php
                            $query = "SELECT * FROM vehicle";
                            $result = mysqli_query($connect, $query);
                            if(mysqli_num_rows($result) > 0)
                            {
                                while($row = mysqli_fetch_array($result))
                                {
                                    ?>
                            <div class="car-box-2" >
                                <div class="row g-0">
                                    <div class="col-lg-5 col-md-5">
                                        <div class="car-thumbnail">
                                            <a href="ViewCar.html" class="car-img">
                                                <?php  echo "<img id='foo' src='Dashboard/".$row['image']."' />"; ?>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-lg-7 col-md-7 align-self-center">
                                        <div class="detail">
                                            <h3 class="title">
                                                <?php
								                    //echo "<a href='ViewCar.php?id=".$row['id']."'>$row["make"] . ' ' . $row["model"]</a>";
                                                ?>
                                                <a href="ViewCar.php"><?php echo $row["make"] . ' ' . $row["model"]; ?></a>
                                            </h3>
                                            <h5 class="location">
                                                <a href="ViewCar.html">
                                                    $ <?php echo $row["sellPrice"]; ?>
                                                </a>
                                            </h5>
                                            <p><?php echo $row["options"]; ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/popper.min.js"></script>
            <script src="assets/js/bootstrap.bundle.min.js"></script>
            <script  src="assets/js/bootstrap-submenu.js"></script>
            <script  src="assets/js/rangeslider.js"></script>
            <script  src="assets/js/jquery.mb.YTPlayer.js"></script>
            <script  src="assets/js/bootstrap-select.min.js"></script>
            <script  src="assets/js/jquery.easing.1.3.js"></script>
            <script  src="assets/js/jquery.scrollUp.js"></script>
            <script  src="assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
            <script  src="assets/js/ie10-viewport-bug-workaround.js"></script>
            </div>
    </body>
</html>
