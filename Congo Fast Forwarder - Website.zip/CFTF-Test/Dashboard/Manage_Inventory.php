<?php
require('connection.inc.php');
$vin='';
$make='';
$model='';
$year='';
$exteriorColour='';
$interiorColour='';
$options='';
$price='';
$sellPrice='';
$image1='';
/*$image2='';
$image3='';
$image4='';
$image5='';
$image6='';*/

$msg='';
$image_required='required';
/*$image_required2='required';
$image_required3='required';
$image_required4='required';
$image_required5='required';
$image_required6='required';*/

if(isset($_GET['vehicleID']) && $_GET['vehicleID']!=''){
	$image_required='';
	$id=get_safe_value($conn,$_GET['vehicleID']);
	$res=mysqli_query($conn,"select * from vehicle where vehicleID='$vehicleID'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$vin=$row['vin'];
    $make=$row['make'];
    $model=$row['model'];
    $year=$row['year'];
    $exteriorColour=$row['exteriorColour'];
    $interiorColour=$row['interiorColour'];
		$options=$row['options'];
		$price=$row['price'];
		$sellPrice=$row['sellPrice'];
	}else{
		header('location:Inventory.php');
		die();
	}
}

if(isset($_POST['submit'])){
  $vin=get_safe_value($conn,$_POST['vin']);
  $make=get_safe_value($conn,$_POST['make']);
  $model=get_safe_value($conn,$_POST['model']);
  $year=get_safe_value($conn,$_POST['year']);
	$price=get_safe_value($conn,$_POST['price']);
	$sellPrice=get_safe_value($conn,$_POST['sellPrice']);

	$res=mysqli_query($conn,"select * from vehicle where vin='$vin'");
	$check=mysqli_num_rows($res);
	if($check>0){
		if(isset($_GET['vehicleID']) && $_GET['vehicleID']!=''){
			$getData=mysqli_fetch_assoc($res);
			if($id==$getData['vehicleID']){

			}else{
				$msg="Product already exists";
			}
		}else{
			$msg="Product already exists";
		}
	}


	if($_GET['id']==0){
		if($_FILES['image1']['type']!='image/png' && $_FILES['image1']['type']!='image/jpg' && $_FILES['image1']['type']!='image/jpeg'){
			$msg="Please select only png,jpg image format";
		}
	}else{
		if($_FILES['image1']['type']!=''){
				if($_FILES['image1']['type']!='image/png' && $_FILES['image1']['type']!='image/jpg' && $_FILES['image1']['type']!='image/jpeg'){
				$msg="Please select only png,jpg image format";
			}
		}
	}

	if($msg==''){
		if(isset($_GET['vehicleID']) && $_GET['vehicleID']!=''){
			if($_FILES['image1']['vin']!=''){
				$image=rand(111111111,999999999).'_'.$_FILES['image1']['vin'];
				move_uploaded_file($_FILES['image']['tmp_name'],PRODUCT_IMAGE_SERVER_PATH.$image);
				$update_sql="update vehicle set vin='$vin',make='$make',model='$model',year='$year',exteriorColour='$exteriorColour',interiorColour='$interiorColour',options='$options',image1='$image1',price='$price',sellPrice='$sellprice', where vehicleID='$vehicleID'";
			}else{
				$update_sql="update vehicle set vin='$vin',make='$make',model='$model',year='$year',exteriorColour='$exteriorColour',interiorColour='$interiorColour',options='$options',price='$price',sellPrice='$sellprice', where vehicleID='$vehicleID'";
			}
			mysqli_query($conn,$update_sql);
		}else{
			$image=rand(111111111,999999999).'_'.$_FILES['image1']['type'];
			move_uploaded_file($_FILES['image1']['tmp_name'],PRODUCT_IMAGE_SERVER_PATH.$image1);
			mysqli_query($conn,"insert into vehicle(vin,make,model,year,exteriorColour,interiorColour,options,price,sellPrice,image1,image2,image3,image4,image5,image6) values('$vin','$make','$model','$year','$exteriorColour','$interiorColour','$options','$price','$sellPrice','$image1','$image2','$image3','$image4','$image5','$image6')");
		}
		header('location:Inventory.php');
		die();
	}
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
        <link rel="stylesheet" href="style.css">
        <title>CFTF - Dashboard</title>
    </head>

    <body>
        <div class="side-menu">
            <ul>
                <br><br><br><br>
                <li>
                  <a href="index.php">
                    <span class="material-icons-sharp">dashboard</span>
                    <span>Dashboard</span>
                </a>
                </li>
                <li>
                  <a href="Orders.php">
                    <span class="material-icons-sharp">task</span>
                    <span>Orders</span>
                  </a>
                </li>
                <li>
                  <a href="Sales.php">
                    <span class="material-icons-sharp">point_of_sale</span>
                    <span>Sales</span>
                  </a>
                </li>
                <li>
                  <a href="Inventory.php">
                    <span class="material-icons-sharp">inventory_2</span>
                    <span>Inventory</span>
                  </a>
                </li>
                <li>
                  <a href="">
                    <span class="material-icons-sharp">person_outline</span>
                    <span>Profile</span>
                  </a>
                </li>
                <br><br><br><br>
                <li>
                  <a href="logout.php">
                    <span class="material-icons-sharp">logout</span>
                    <span>Logout</span>
                  </a>
                </li>
            </ul>
        </div>
        <div class="container">
            <div class="header">
                <div class="nav">
                    <div class="user">
                        <div class="img-case">
                            <img src="Images/user.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="content">
                <div class="content-3">
                    <div class="recent-sales">
                        <div class="title">
                            <h2>Add/Vehicle a Vehicle</h2>
                        </div>

              			<div class="Edit-Add-Vehicle">
                      <label>VIN</label>
              				<input type="text" class="field" placeholder="AAVZBB3CD901726956">
                      <label>Make</label>
              				<input type="text" class="field" placeholder="Volkswagen">
                      <label>Model</label>
              				<input type="text" class="field" placeholder="Polo GTI">
                      <label>Year</label>
              			  <input type="text" class="field" placeholder="2015">
                      <label>Exterior Colour</label>
              			  <input type="text" class="field" placeholder="White">
                      <label>Interior Colour</label>
              			  <input type="text" class="field" placeholder="Black">
                      <label>Description</label>
              			  <textarea placeholder="ONLY 34500KMs, Sunroof, Xenon Lights...." class="field"></textarea>
                      <label>Price</label>
              			  <input type="text" class="field" placeholder="245000.00">
                      <label>Sell Price</label>
              			  <input type="text" class="field" placeholder="281750.00">
                      <label>Category</label>
              			  <input type="text" class="field" placeholder="Hatchback">
                        <table>
                          <tr>
                            <td>
                              <label>Image 1 - Front           </label>
                              <input type="file" name="image1" class="form-control" <?php echo  $image_required?>
                            </td>
                            <!-- <td>
                              <label>Image 4 - Front Diagonal  </label>
                              <input type="file" name="image" class="form-control" <?php echo  $image_required4?>
                            </td>
                          </tr>
                          <tr>
                            <td>
                              <label>Image 2 - Rear            </label>
                              <input type="file" name="image" class="form-control" <?php echo  $image_required2?>
                            </td>
                            <td>
                              <label>Image 5 - Rear Diagonal   </label>
                              <input type="file" name="image" class="form-control" <?php echo  $image_required5?>
                            </td>
                        </tr>
                        <tr>
                          <td>
                            <label>Image 3 - Side Profile      </label>
                            <input type="file" name="image" class="form-control" <?php echo  $image_required3?>
                          </td>
                          <td>
                            <label>Image 6 - Interior          </label>
                            <input type="file" name="image" class="form-control" <?php echo  $image_required6?>
                          </td> -->
                        </tr>
                      </table>
                      <br><br>
              				<button class="btn" name="submit" type="submit">Submit</button>
                      <div class="field_error"><?php echo $msg?></div>
              			</div>
                </div>
            </div>
        </div>
    </body>
</html>
