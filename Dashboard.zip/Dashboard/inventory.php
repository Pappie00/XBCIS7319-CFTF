<?php
require('connection.inc.php');
require('functions.inc.php');
if(isset($_SESSION['ADMIN_LOGIN']) && $_SESSION['ADMIN_LOGIN']!=''){

}else{
	header('location:login.php');
	die();
}

if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($conn,$_GET['type']);
	if($type=='delete'){
		$id=get_safe_value($conn,$_GET['id']);
		$delete_sql="delete from vehicle where id='$id'";
		mysqli_query($conn,$delete_sql);
	}
}

$sql="select * from vehicle";
$res=mysqli_query($conn,$sql);
?>
<?php include 'download.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CFTF - Dashboard</title> 
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
</head>
<body>
    <nav>
        <div class="logo-name">
            <div class="logo-image">
                <img src="Images/logo-bl-null.png" alt="">
            </div>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li><a href="index.php">
                    <i class="uil uil-estate"></i>
                    <span class="link-name">Dashboard</span>
                </a></li>
                <li><a href="orders.php">
                    <i class="uil uil-transaction"></i>
                    <span class="link-name">Orders</span>
                </a></li>
                <li><a href="sales.php">
                    <i class="uil uil-invoice"></i>
                    <span class="link-name">Sales</span>
                </a></li>
                <li><a href="inventory.php">
                    <i class="uil uil-car"></i>
                    <span class="link-name">Inventory</span>
                </a></li>
                <li><a href="users.php">
                    <i class="uil uil-users-alt"></i>
                    <span class="link-name">Profile Management</span>
                </a></li>
            </ul>
            
            <ul class="logout-mode">
                <li><a href="logout.php">
                    <i class="uil uil-signout"></i>
                    <span class="link-name">Logout</span>
                </a></li>
            </ul>
        </div>
    </nav>
    <section class="dashboard">
        <div class="dash-content">
            <div class="activity">
                <div class="titleCon">
                    <div class="title">
                        <i class="uil uil-car"></i>
                        <span class="text">Vehicle Inventory</span>
                    </div>
                    <a href="manage_inventory.php" class="btn">Add New Vehicle</a>
                </div>
                    <table>
                    <tr>
                        <th>ID</th>
                        <th>VIN</th>
                        <th>Make</th>
                        <th>Model</th>
                        <th>Year</th>
                        <th>Exterior Colour</th>
                        <th>Interior Colour</th>
                        <!-- <th>Options</th> -->
                        <th>Price ($)</th>
                        <th>Sell Price ($)</th>
                        <th>Category</th>
                        <!-- <th>Image</th> -->
                        <th></th>
                        <th></th>
                    </tr>
                    <?php
                    while($row=mysqli_fetch_assoc($res)){?>
                    <tr>
                        <td><?php echo $row['id']?></td>
                        <td><?php echo $row['vin']?></td>
                        <td><?php echo $row['make']?></td>
                        <td><?php echo $row['model']?></td>
                        <td><?php echo $row['year']?></td>
                        <td><?php echo $row['exteriorColour']?></td>
                        <td><?php echo $row['interiorColour']?></td>
                        <!-- <td><?php //echo $row['options']?></td> -->
                        <td><?php echo $row['price']?></td>
                        <td><?php echo $row['sellPrice']?></td>
                        <td><?php echo $row['category']?></td>
                        <!-- <td><img src="<?php //echo $row["image"]; ?>" width="50px" height="50px"></td> -->
                        <td></td>
                        <td><?php echo "<a href='manage_inventory.php?id=".$row['id']."'><i class='uil uil-edit'></i></a>";?></td>
                        <td><?php echo "<a onclick='confirmDeleteCar()' href='?type=delete&id=".$row['id']."'><i class='uil uil-trash'></i></a>";?></td>
                    </tr>
                    <?php } ?>
                    </table>
            </div>
        </div>
    </section>
    <script src="script.js"></script>
</body>
</html>