<?php
session_start();
//connecting to the database
$conn=mysqli_connect("localhost","root","","cftf");

//Creating file/server paths for retrieving files and data
define('SERVER_PATH',$_SERVER['DOCUMENT_ROOT'].'/CFTF-Test2/Dashboard/');
define('SITE_PATH','http://localhost/CFTF-Test2/Dashboard/');

//Creating file paths for uploading and editing images
define('PRODUCT_IMAGE_SERVER_PATH',SERVER_PATH.'product-images/');
define('PRODUCT_IMAGE_SITE_PATH',SITE_PATH.'product-images/');
//Creating file paths for uploading and editing invoices
define('PRODUCT_INVOICE_SERVER_PATH',SERVER_PATH.'product-invoice/');
define('PRODUCT_INVOICE_SITE_PATH',SITE_PATH.'product-invoice/');
//Creating file paths for uploading and editing orders
define('PRODUCT_ORDER_SERVER_PATH',SERVER_PATH.'product-order/');
define('PRODUCT_ORDER_SITE_PATH',SITE_PATH.'product-order/');
?>
