<?php
session_start();
//connecting to the database
$conn=mysqli_connect("localhost","root","","cftf");

// initializing variables
$username = "";
$errors = array();

//REGISTERING A USER
if (isset($_POST['reg_user']))
{
  //Get all input values from the form
  $username = mysqli_real_escape_string($conn, $_POST['username']);
  $fullName = mysqli_real_escape_string($conn, $_POST['fullName']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $phone = mysqli_real_escape_string($conn, $_POST['phone']);
  $address = mysqli_real_escape_string($conn, $_POST['address']);
  $password_1 = mysqli_real_escape_string($conn, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($conn, $_POST['password_2']);

  // form validation: ensure that the form is correctly filled by adding (array_push()) corresponding error unto $errors array
  if (empty($username))
  {
     array_push($errors, "Username is required");
  }
  if (empty($password_1))
  {
     array_push($errors, "Password is required");
  }
  if ($password_1 != $password_2)
  {
       array_push($errors, "The two passwords do not match");
  }

  //cross-refence database to make sure user does not exist
  $user_check_query = "SELECT * FROM admin WHERE username='$username' LIMIT 1";
  $result = mysqli_query($conn, $user_check_query);
  $user = mysqli_fetch_assoc($result);

  if ($user)
  { // if user exists
    if ($user['username'] === $username)
    {
      array_push($errors, "Username already exists");
    }
  }
  //Register user where there are no errors in form
  if (count($errors) == 0)
  {
    //encryptying password in the database
      $password = md5($password_1);
    //adding new user to database
      $query = "INSERT INTO admin (username, fullName, email, phone, address, password)
                VALUES('$username', '$fullName', '$email', '$phone', '$address' '$password')";
      mysqli_query($conn, $query);
      $_SESSION['username'] = $username;
      $_SESSION['success'] = "You are now registeed";
      header('location: logout.php');
  }
}

//Creating file/server paths for retrieving files and data
define('SERVER_PATH',$_SERVER['DOCUMENT_ROOT'].'/CFTF2/Dashboard/');
define('SITE_PATH','http://localhost/CFTF2/Dashboard/');

//Creating file paths for uploading and editing images
define('PRODUCT_IMAGE_SERVER_PATH',SERVER_PATH.'product-images/');
define('PRODUCT_IMAGE_SITE_PATH',SITE_PATH.'product-images/');
//Creating file paths for uploading and editing invoices
define('PRODUCT_INVOICE_SERVER_PATH',SERVER_PATH.'product-invoice/');
define('PRODUCT_INVOICE_SITE_PATH',SITE_PATH.'product-invoice/');
//Creating file paths for uploading and editing orders
define('PRODUCT_ORDER_SERVER_PATH',SERVER_PATH.'product-order/');
define('PRODUCT_ORDER_SITE_PATH',SITE_PATH.'product-order/');
//Creating file paths for uploading and editing quotes
define('PRODUCT_QUOTE_SERVER_PATH',SERVER_PATH.'product-quote/');
define('PRODUCT_QUOTE_SITE_PATH',SITE_PATH.'product-quote/');
?>
