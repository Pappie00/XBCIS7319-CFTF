<?php
// connect to database
$conn = mysqli_connect('localhost', 'root', '', 'cftf');

$sql = "SELECT * FROM invoice";
$result = mysqli_query($conn, $sql);
$files = mysqli_fetch_all($result, MYSQLI_ASSOC);
// Downloads files
if (isset($_GET['file_id'])) {
    $id = $_GET['file_id'];

    // fetch file to download from database
    $sql = "SELECT * FROM invoice WHERE id=$id";
    $result = mysqli_query($conn, $sql);

    $file = mysqli_fetch_assoc($result);
    $filepath = 'product-invoice/' . $file['name'];

    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($filepath));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize('product-invoice/' . $file['name']));
        readfile('product-invoice/' . $file['name']);

        // Now update downloads count
        $newCount = $file['invoiceFile'] + 1;
        $updateQuery = "UPDATE invoice SET invoiceFile=$newCount WHERE id=$id";
        mysqli_query($conn, $updateQuery);
        exit;
    }

}
?>