<?php
require('connection.inc.php');
require('functions.inc.php');
$invoiceNum='';
$fk_vin='';
$fk_salesPersonID='';
$fk_clientID='';
$statusInvoice='';
$invoiceFile='';

$msg='';
$image_required='required';
if(isset($_GET['id']) && $_GET['id']!=''){
	$image_required='';
	$id=get_safe_value($conn,$_GET['id']);
	$res=mysqli_query($conn,"select * from invoice where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$invoiceNum=$row['invoiceNum'];
		$fk_vin=$row['fk_vin'];
        $fk_salesPersonID=$row['fk_salesPersonID'];
		$fk_clientID=$row['fk_clientID'];
		$statusInvoice=$row['statusInvoice'];
	}else{
		header('location:Sales.php');
		die();
	}
}

if(isset($_POST['submit'])){
	$invoiceNum=get_safe_value($conn,$_POST['invoiceNum']);
	$fk_vin=get_safe_value($conn,$_POST['fk_vin']);
	$fk_salesPersonID=get_safe_value($conn,$_POST['fk_salesPersonID']);
	$fk_clientID=get_safe_value($conn,$_POST['fk_clientID']);
	$statusInvoice=get_safe_value($conn,$_POST['statusInvoice']);

	$res=mysqli_query($conn,"select * from invoice where invoiceNum='$invoiceNum'");
	$check=mysqli_num_rows($res);
	if($check>0){
		if(isset($_GET['id']) && $_GET['id']!=''){
			$getData=mysqli_fetch_assoc($res);
			if($id==$getData['id']){

			}else{
				$msg="Invoice already exists";
			}
		}else{
			$msg="Invoice already exists";
		}
	}


	/*if($_GET['id']==0){
		if($_FILES['invoiceFile']['type']!='invoiceFile/png' && $_FILES['invoiceFile']['type']!='invoiceFile/jpg' && $_FILES['invoiceFile']['type']!='invoiceFile/pdf' && $_FILES['invoiceFile']['type']!='invoiceFile/jpeg'){
			$msg="Please select only png,jpg,pdf invoice format";
		}
	}else{
		if($_FILES['invoiceFile']['type']!=''){
				if($_FILES['invoiceFile']['type']!='invoiceFile/png' && $_FILES['invoiceFile']['type']!='invoiceFile/jpg' && $_FILES['invoiceFile']['type']!='invoiceFile/pdf' && $_FILES['invoiceFile']['type']!='invoiceFile/jpeg'){
				$msg="Please select only png,jpg,pdf format format";
			}
		}
	}*/

	if($msg==''){
		if(isset($_GET['id']) && $_GET['id']!=''){
			if($_FILES['invoiceFile']['name']!=''){
				//$image=rand(111111111,999999999).'_'.$_FILES['image']['description'];
				//move_uploaded_file($_FILES['image']['tmp_name'],PRODUCT_IMAGE_SERVER_PATH.$image);
				$invoiceFile="product-invoice/".''.$_FILES['invoiceFile']['name'];
				move_uploaded_file($_FILES['invoiceFile']['tmp_name'],PRODUCT_INVOICE_SERVER_PATH.basename($_FILES['invoiceFile']['name']));

				$update_sql="update invoice set invoiceNum='$invoiceNum',fk_vin='$fk_vin',invoiceFile='$invoiceFile',fk_salesPersonID='$fk_salesPersonID',fk_clientID='$fk_clientID',statusInvoice='$statusInvoice' where id='$id'";
			}else{
				$update_sql="update invoice set invoiceNum='$invoiceNum',fk_vin='$fk_vin',fk_salesPersonID='$fk_salesPersonID',fk_clientID='$fk_clientID',statusInvoice='$statusInvoice' where id='$id'";
			}
			mysqli_query($conn,$update_sql);
		}else{
			//$image=rand(111111111,999999999).'_'.$_FILES['image']['type'];
			//move_uploaded_file($_FILES['image']['tmp_name'],PRODUCT_IMAGE_SERVER_PATH.$image);
			$invoiceFile="product-invoice/".''.$_FILES['invoiceFile']['name'];
			move_uploaded_file($_FILES['invoiceFile']['tmp_name'],PRODUCT_INVOICE_SERVER_PATH.basename($_FILES['invoiceFile']['name']));

			mysqli_query($conn,"insert into invoice(invoiceNum, fk_vin, fk_salesPersonID, fk_clientID, statusInvoice, invoiceFile) values('$invoiceNum', '$fk_vin', '$fk_salesPersonID', '$fk_clientID', '$statusInvoice', '$invoiceFile')");
		}
		header('location:Sales.php');
		die();
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CFTF - Dashboard</title> 
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
</head>
<body>
    <nav>
        <div class="logo-name">
            <div class="logo-image">
                <img src="Images/logo-bl-null.png" alt="">
            </div>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li><a href="index.php">
                    <i class="uil uil-estate"></i>
                    <span class="link-name">Dashboard</span>
                </a></li>
                <li><a href="orders.php">
                    <i class="uil uil-transaction"></i>
                    <span class="link-name">Orders</span>
                </a></li>
                <li><a href="sales.php">
                    <i class="uil uil-invoice"></i>
                    <span class="link-name">Sales</span>
                </a></li>
                <li><a href="inventory.php">
                    <i class="uil uil-car"></i>
                    <span class="link-name">Inventory</span>
                </a></li>
                <li><a href="users.php">
                    <i class="uil uil-users-alt"></i>
                    <span class="link-name">Profile Management</span>
                </a></li>
            </ul>
            
            <ul class="logout-mode">
                <li><a href="logout.php">
                    <i class="uil uil-signout"></i>
                    <span class="link-name">Logout</span>
                </a></li>
            </ul>
        </div>
    </nav>
    <section class="dashboard">
        <div class="dash-content">
            <div class="activity">
                <div class="titleCon">
                    <div class="title">
                        <i class="uil uil-invoice"></i>
                        <span class="text">Add/Edit A Sale</span>
                    </div>
                </div>
                    <form method="post">
                                <div class="txt_field">
                                    <input type="text" name="invoiceNum" required value="<?php echo $invoiceNum?>">
                                    <span></span>
                                    <label>Invoice Number</label>
                                </div>
                                <div class="txt_field">
                                    <input type="text" name="fk_vin" required value="<?php echo $fk_vin?>">
                                    <span></span>
                                    <label>Vehicle VIN</label>
                                </div>
                                <div class="txt_field">
                                    <input type="text" name="fk_salesPersonID" required value="<?php echo $fk_salesPersonID?>">
                                    <span></span>
                                    <label>Sales Person ID</label>
                                </div>
                                <div class="txt_field">
                                    <input type="text" name="fk_clientID" required value="<?php echo $fk_clientID?>">
                                    <span></span>
                                    <label>Client ID</label>
                                </div>
                                <div class="txt_field">
                                    <input type="text" name="statusInvoice" required value="<?php echo $statusInvoice?>">
                                    <span></span>
                                    <label>Invoice Status</label>
                                </div>
                                <div class="txt_field_upload">
                                    <label style="color: #adadad;">Upload Invoice   </label>
                                    <input type="file" name="invoiceFile" class="form-control" <?php echo  $invoiceFile?>>
                                </div>
                                <div class="txt_field_upload">
                                    <label><br><br></label>
                                </div>
                            <input type="submit" name="submit" value="submit">
                    <div class="field_error"><?php echo $msg?></div>
                </form>
            </div>
        </div>
    </section>
</body>
</html>
<?php
    require('footer.inc.php');
?>
