<?php
require('header.inc.php');
$orderNum='';
$statusOrder='';
$fk_clientID='';
$fk_vin='';
$fk_SalesPersonID='';
$orderFile='';

$msg='';
$image_required='required';
if(isset($_GET['id']) && $_GET['id']!=''){
	$image_required='';
	$id=get_safe_value($conn,$_GET['id']);
	$res=mysqli_query($conn,"select * from orders where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$orderNum=$row['orderNum'];
		$statusOrder=$row['statusOrder'];
		$fk_clientID=$row['fk_clientID'];
		$fk_vin=$row['fk_vin'];
        $fk_SalesPersonID=$row['fk_SalesPersonID'];
	}else{
		header('location:Orders.php');
		die();
	}
}

if(isset($_POST['submit'])){
	$orderNum=get_safe_value($conn,$_POST['orderNum']);
	$statusOrder=get_safe_value($conn,$_POST['statusOrder']);
	$fk_clientID=get_safe_value($conn,$_POST['fk_clientID']);
	$fk_vin=get_safe_value($conn,$_POST['fk_vin']);
	$fk_SalesPersonID=get_safe_value($conn,$_POST['fk_SalesPersonID']);

	$res=mysqli_query($conn,"select * from orders where orderNum='$orderNum'");
	$check=mysqli_num_rows($res);
	if($check>0){
		if(isset($_GET['id']) && $_GET['id']!=''){
			$getData=mysqli_fetch_assoc($res);
			if($id==$getData['id']){

			}else{
				$msg="Order already exists";
			}
		}else{
			$msg="Order already exists";
		}
	}


	/*if($_GET['id']==0){
		if($_FILES['invoiceFile']['type']!='invoiceFile/png' && $_FILES['invoiceFile']['type']!='invoiceFile/jpg' && $_FILES['invoiceFile']['type']!='invoiceFile/pdf' && $_FILES['invoiceFile']['type']!='invoiceFile/jpeg'){
			$msg="Please select only png,jpg,pdf invoice format";
		}
	}else{
		if($_FILES['invoiceFile']['type']!=''){
				if($_FILES['invoiceFile']['type']!='invoiceFile/png' && $_FILES['invoiceFile']['type']!='invoiceFile/jpg' && $_FILES['invoiceFile']['type']!='invoiceFile/pdf' && $_FILES['invoiceFile']['type']!='invoiceFile/jpeg'){
				$msg="Please select only png,jpg,pdf format format";
			}
		}
	}*/

	if($msg==''){
		if(isset($_GET['id']) && $_GET['id']!=''){
			if($_FILES['orderFile']['name']!=''){
				//$image=rand(111111111,999999999).'_'.$_FILES['image']['description'];
				//move_uploaded_file($_FILES['image']['tmp_name'],PRODUCT_IMAGE_SERVER_PATH.$image);
				$orderFile="product-order/".''.$_FILES['orderFile']['name'];
				move_uploaded_file($_FILES['orderFile']['tmp_name'],PRODUCT_ORDER_SERVER_PATH.basename($_FILES['orderFile']['name']));

				$update_sql="update orders set orderNum='$orderNum',fk_vin='$fk_vin',orderFile='$orderFile',fk_SalesPersonID='$fk_SalesPersonID',fk_clientID='$fk_clientID',statusOrder='$statusOrder' where id='$id'";
			}else{
				$update_sql="update orders set orderNum='$orderNum',fk_vin='$fk_vin',fk_SalesPersonID='$fk_SalesPersonID',fk_clientID='$fk_clientID',statusOrder='$statusOrder' where id='$id'";
			}
			mysqli_query($conn,$update_sql);
		}else{
			//$image=rand(111111111,999999999).'_'.$_FILES['image']['type'];
			//move_uploaded_file($_FILES['image']['tmp_name'],PRODUCT_IMAGE_SERVER_PATH.$image);
			$orderFile="product-order/".''.$_FILES['orderFile']['name'];
			move_uploaded_file($_FILES['orderFile']['tmp_name'],PRODUCT_ORDER_SERVER_PATH.basename($_FILES['orderFile']['name']));

			mysqli_query($conn,"insert into orders(orderNum, fk_vin, fk_SalesPersonID, fk_clientID, statusOrder, orderFile) values('$orderNum', '$fk_vin', '$fk_SalesPersonID', '$fk_clientID', '$statusOrder', '$orderFile')");
		}
		header('location:Orders.php');
		die();
	}
}
?>
<div class="content pb-0">
            <div class="animated fadeIn">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="card">
                        <div class="card-header"><strong>Add/Edit An Order</strong></div>
                        <form method="post" enctype="multipart/form-data">
													<div class="card-body card-block">
															<div class="form-group">
																<label for="categories" class=" form-control-label">Order Number </label>
																<input type="text" name="orderNum" placeholder="Enter invoice number" class="form-control" required value="<?php echo $orderNum?>">
															</div>
															<div class="form-group">
																<label for="categories" class=" form-control-label">Vehicle VIN</label>
																<input type="text" name="fk_vin" placeholder="Enter vehicle identification number" class="form-control" required value="<?php echo $fk_vin?>">
															</div>
															<div class="form-group">
																<label for="categories" class=" form-control-label">Sales Person ID</label>
																<input type="text" name="fk_SalesPersonID" placeholder="Enter sales person ID" class="form-control" required value="<?php echo $fk_SalesPersonID?>">
															</div>
															<div class="form-group">
																<label for="categories" class=" form-control-label">Client ID</label>
																<input type="text" name="fk_clientID" placeholder="Enter client ID" class="form-control" required value="<?php echo $fk_clientID?>">
															</div>
                                                            <div class="form-group">
																<label for="categories" class=" form-control-label">Order Status</label>
																<input type="text" name="statusOrder" placeholder="Enter Order Status" class="form-control" required value="<?php echo $statusOrder?>">
															</div> 
															<div class="form-group">
																<label for="categories" class=" form-control-label">Upload Order Document</label>
																<input type="file" name="orderFile" class="form-control" <?php echo  $image_required?>>
															</div>
							   							<button id="payment-button" name="submit" type="submit" class="btn btn-lg btn-info btn-block">
							   									<span id="payment-button-amount">Submit</span>
							   							</button>
							   					<div class="field_error"><?php echo $msg?></div>
												</div>
											</form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
		 <?php
			require('footer.inc.php');
			?>
