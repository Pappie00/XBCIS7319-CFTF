<?php
require('header.inc.php');

if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($conn,$_GET['type']);
	if($type=='delete'){
		$id=get_safe_value($conn,$_GET['id']);
		$delete_sql="delete from invoice where id='$id'";
		mysqli_query($conn,$delete_sql);
	}
}

$sql="select * from invoice";
$res=mysqli_query($conn,$sql);

$result = mysqli_query($conn, $sql);
$files = mysqli_fetch_all($result, MYSQLI_ASSOC);
// Downloads files
if (isset($_GET['file_id'])) {
    $id = $_GET['file_id'];

    // fetch file to download from database
    $sql = "SELECT * FROM invoice WHERE id=$id";
    $result = mysqli_query($conn, $sql);

    $file = mysqli_fetch_assoc($result);
    $filepath = PRODUCT_INVOICE_SERVER_PATH.basename($file['name']);

    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($filepath));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        //header('Content-Length: ' . filesize('product-invoice/' . $file['name']));
        readfile(PRODUCT_INVOICE_SERVER_PATH.basename($_FILES['invoiceFile']['name']));

        // Now update downloads count
        $newCount = $file['invoiceFile'] + 1;
        $updateQuery = "UPDATE invoice SET invoiceFile=$newCount WHERE id=$id";
        mysqli_query($conn, $updateQuery);
        exit;
    }

}
?>
<?php include 'download.php';?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
				   <h4 class="box-title">Sales</h4>
				   <h4 class="box-link"><a href="ManageSales.php">Add New Sale</a> </h4>
				</div>
				<div class="card-body--">
				   <div class="table-stats order-table ov-h">
					  <table class="table ">
						 <thead>
							<tr>
                 <th>ID</th>
							   <th>Invoice</th>
							   <th>Vehicle</th>
							   <th>Salesperson</th>
							   <th>Client</th>
							   <th>Status</th>
							   <th></th>
							   <th></th>
							</tr>
						 </thead>
						 <tbody>
							<?php
							while($row=mysqli_fetch_assoc($res)){?>
							<tr>
							   <td><?php echo $row['id']?></td>
							   <td><?php echo $row['invoiceNum']?></td>
							   <td><?php echo $row['fk_vin']?></td>
							   <td><?php echo $row['fk_salesPersonID']?></td>
							   <td><?php echo $row['fk_clientID']?></td>
							   <td><?php echo $row['statusInvoice']?></td>
							  </td>
							   <td>
								<?php
								echo "<span class='badge badge-edit'><a href='ManageSales.php?id=".$row['id']."'>Edit</a></span>&nbsp;";

								echo "<span class='badge badge-delete'><a href='?type=delete&id=".$row['id']."'>Delete</a></span>";
								?>
							   </td>
							</tr>
							<?php } ?>
						 </tbody>
					  </table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>
<?php
require('footer.inc.php');
?>
