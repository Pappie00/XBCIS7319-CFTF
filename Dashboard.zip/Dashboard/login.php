<?php
require('connection.inc.php');
require('functions.inc.php');
$msg='';
if(isset($_POST['submit'])){
	$username=get_safe_value($conn,$_POST['username']);
	$password=get_safe_value($conn,$_POST['password']);
	$sql="select * from admin where username='$username' and password='$password'";
	$res=mysqli_query($conn,$sql);
	$count=mysqli_num_rows($res);
	if($count>0){
		$_SESSION['ADMIN_LOGIN']='yes';
		$_SESSION['ADMIN_USERNAME']=$username;
		header('location:index.php');
		die();
	}else{
		$msg="Invalid USERNAME and/or PASSWORD";
	}
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CFTF - Login</title> 
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div class="center">
      <img src="Images/logo-bl.png" width=150px height=100px style="padding-bottom:5%;" class="login-logo">
      <h1>LOGIN</h1>
      <form method="post">
        <div class="field_error"><?php echo $msg?></div>
        <div class="txt_field">
          <input type="text" name="username" required>
          <span></span>
          <label>Username</label>
        </div>
        <div class="txt_field">
          <input type="password" name="password" required>
          <span></span>
          <label>Password</label>
        </div>
        <!-- <a href="forgotpassword.html"><div class="pass">Forgot Password?</div></a> -->
        <input type="submit" name="submit" value="Login">
        <div class="signup_link">
          Go To <a href="../index.html">WEBSITE</a>
        </div>
      </form>
    </div>
  </body>
</html>
