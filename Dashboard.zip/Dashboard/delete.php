<?php
require('connection.inc.php');
require('functions.inc.php');

		$id=get_safe_value($conn,$_GET['id']);
		$delete_sql="delete from orders where id='$id'";
		mysqli_query($conn,$delete_sql);
        header('location:Orders.php');
?>