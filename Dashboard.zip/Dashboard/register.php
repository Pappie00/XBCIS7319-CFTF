<?php 
require('connection.inc.php');
require('functions.inc.php');
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CFTF - Registration Page</title> 
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <div class="center">
      <img src="Images/logo-bl.png" width=150px height=100px class="login-logo">
      <form method="post" action="register.php">
      <?php include('errors.php'); ?>
        <div class="txt_field">
          <input type="text" name="username" required>
          <span></span>
          <label>Username*</label>
        </div>
        <div class="txt_field">
          <input type="text" name="fullName" required>
          <span></span>
          <label>Full Name</label>
        </div>
        <div class="txt_field">
          <input type="text" name="email" required>
          <span></span>
          <label>Email</label>
        </div>
        <div class="txt_field">
          <input type="text" name="address" required>
          <span></span>
          <label>Address</label>
        </div>
        <div class="txt_field">
          <input type="text" name="phone"  required>
          <span></span>
          <label>Phone Number</label>
        </div>
        <div class="txt_field">
          <input type="password" name="password_1" required>
          <span></span>
          <label>Password*</label>
        </div>
        <div class="txt_field">
          <input type="password" name="password_2" required>
          <span></span>
          <label>Confirm Password*</label>
        </div>
        <!-- <a href="forgotpassword.html"><div class="pass">Forgot Password?</div></a> -->
        <input type="submit" name="reg_user" value="Register">
        <div class="signup_link">
          Return To <a href="login.php">LOGIN</a>
        </div>
      </form>
    </div>
  </body>
</html>
