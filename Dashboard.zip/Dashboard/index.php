<?php
require('connection.inc.php');
require('functions.inc.php');
if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($conn,$_GET['type']);
	if($type=='delete'){
		$id=get_safe_value($conn,$_GET['invoiceNum']);
		$delete_sql="delete from invoice where invoiceNum='$invoiceNum'";
		mysqli_query($conn,$delete_sql);
	}
}
$sql="select * from invoice LIMIT 5;";
$res=mysqli_query($conn,$sql);
$sql = "SELECT count(*) from invoice";
$result = $conn->query($sql);
$sql = "SELECT count(*) from vehicle";
$result2 = $conn->query($sql);
$sql = "SELECT count(*) from orders";
$result3 = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CFTF - Dashboard</title> 
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
</head>
<body>
    <nav>
        <div class="logo-name">
            <div class="logo-image">
                <img src="Images/logo-bl-null.png" alt="">
            </div>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li><a href="index.php">
                    <i class="uil uil-estate"></i>
                    <span class="link-name">Dashboard</span>
                </a></li>
                <li><a href="orders.php">
                    <i class="uil uil-transaction"></i>
                    <span class="link-name">Orders</span>
                </a></li>
                <li><a href="sales.php">
                    <i class="uil uil-invoice"></i>
                    <span class="link-name">Sales</span>
                </a></li>
                <li><a href="#">
                    <i class="uil uil-car"></i>
                    <span class="link-name">Inventory</span>
                </a></li>
                <li><a href="users.php">
                    <i class="uil uil-users-alt"></i>
                    <span class="link-name">Profile Management</span>
                </a></li>
            </ul>
            
            <ul class="logout-mode">
                <li><a href="logout.php">
                    <i class="uil uil-signout"></i>
                    <span class="link-name">Logout</span>
                </a></li>
            </ul>
        </div>
    </nav>
    <section class="dashboard">
        <div class="dash-content">
            <div class="overview">
                <div class="title">
                    <i class="uil uil-tachometer-fast-alt"></i>
                    <span class="text">Dashboard</span>
                </div>

                <div class="boxes">
                    <div class="box box1">
                        <i class="uil uil-invoice"></i>
                        <span class="text">Total Sales</span>
                        <?php
              				while($row=mysqli_fetch_array($result)){?>
                        <span class="number"><?php echo $row['count(*)']?></span>
                        <?php } ?>
                    </div>
                    <div class="box box2">
                        <i class="uil uil-transaction"></i>
                        <span class="text">Open Orders</span>
                        <?php
              				while($row=mysqli_fetch_array($result3)){?>
                        <span class="number"><?php echo $row['count(*)']?></span>
                        <?php } ?>
                    </div>
                    <div class="box box3">
                        <i class="uil uil-car"></i>
                        <span class="text">Cars in Stock</span>
                        <?php
              				while($row=mysqli_fetch_array($result2)){?>
                        <span class="number"><?php echo $row['count(*)']?></span>
                        <?php } ?>
                    </div>
                </div>
            </div>

            <div class="activity">
                <div class="title">
                    <i class="uil uil-clock-three"></i>
                    <span class="text">Recent Sales</span>
                </div>
                <table>
                    <tr>
                        <th>Invoice</th>
                        <th>Vehicle</th>
                        <th>Sales Person</th>
                        <th>Customer</th>
                        <th>Status</th>
                    </tr>
                    <?php
                        while($row=mysqli_fetch_assoc($res)){?>
                    <tr>
                        <td><?php echo $row['invoiceNum']?></td>
                        <td><?php echo $row['fk_vin']?></td>
                        <td><?php echo $row['fk_salesPersonID']?></td>
                        <td><?php echo $row['fk_clientID']?></td>
                        <td><?php echo $row['statusInvoice']?></td>
                    </tr>
                    <?php } ?>
                </table>
        </div>
    </section>
    <script src="script.js"></script>
</body>
</html>