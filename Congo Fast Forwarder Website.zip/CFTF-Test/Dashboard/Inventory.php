<?php
if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($conn,$_GET['type']);
	if($type=='delete'){
		$id=get_safe_value($conn,$_GET['vehicleID']);
		$delete_sql="delete from vehicle where vehicleID='$vehicleID'";
		mysqli_query($conn,$delete_sql);
	}
}

$sql="select * from vehicle";
$res=mysqli_query($conn,$sql);
?>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
        <link rel="stylesheet" href="style.css">
        <title>CFTF - Dashboard</title>
    </head>

    <body>
        <div class="side-menu">
            <ul>
                <br><br><br><br>
                <li>
                  <a href="index.html">
                    <span class="material-icons-sharp">dashboard</span>
                    <span>Dashboard</span>
                </a>
                </li>
                <li>
                  <a href="">
                    <span class="material-icons-sharp">task</span>
                    <span>Orders and Sales</span>
                  </a>
                </li>
                <li>
                  <a href="Inventory.html">
                    <span class="material-icons-sharp">inventory_2</span>
                    <span>Inventory</span>
                  </a>
                </li>
                <li>
                  <a href="">
                    <span class="material-icons-sharp">person_outline</span>
                    <span>Profile</span>
                  </a>
                </li>
                <br><br><br><br>
                <li>
                  <a href="">
                    <span class="material-icons-sharp">logout</span>
                    <span>Logout</span>
                  </a>
                </li>
            </ul>
        </div>
        <div class="container">
            <div class="header">
                <div class="nav">
                    <div class="user">
                        <div class="img-case">
                            <img src="Images/user.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="content">
                <div class="content-3">
                    <div class="recent-sales">
                        <div class="title">
                            <h2>Inventory</h2>
                            <a href="Manage_Inventory.html" class="btn">Add New Vehicle</a>
                        </div>
                        <table>
                            <tr>
                                <th>ID</th>
                                <th>VIN</th>
                                <th>Make</th>
                                <th>Model</th>
                                <th>Year</th>
                                <th>Exterior Colour</th>
                                <th>Interior Colour</th>
                                <th>Description</th>
                                <th>Price (FC)</th>
                                <th>SellPrice (FC)</th>
                                <th>Category</th>
                            </tr>
                            <tr>
                              <td>4461</td>
                              <td>AAVZBB3CD901726956</td>
                              <td>Volkswagen</td>
                              <td>Polo GTI</td>
                              <td>2015</td>
                              <td>White</td>
                              <td>Black</td>
                              <td>34500KMs, Sunroof, Xenon Lights, Smash and Grab Tint, Full Service History</td>
                              <td>245,000</td>
                              <td>281,750</th>
                              <td>Hatchback</th>
                              <td><span class="material-icons-sharp">edit</span></td>
                              <td><span class="material-icons-sharp">delete_forever</span></td>
                            </tr>
                            <?php
              							while($row=mysqli_fetch_assoc($res)){?>
                            <tr>
                              <td><?php echo $row['vehicleID']?></td>
                              <td><?php echo $row['vin']?></td>
                              <td><?php echo $row['make']?></td>
                              <td><?php echo $row['model']?></td>
                              <td><?php echo $row['year']?></td>
                              <td><?php echo $row['exteriorColour']?></td>
                              <td><?php echo $row['interiorColour']?></td>
                              <td><?php echo $row['options']?></td>
                              <td><?php echo $row['price']?></td>
                              <td><?php echo $row['sellprice']?></td>
                              <td><?php echo $row['category']?></td>
                              <td><span class="material-icons-sharp">edit</span></td>
                              <td><span class="material-icons-sharp">delete_forever</span></td>
                            </tr>
                            <?php } ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
