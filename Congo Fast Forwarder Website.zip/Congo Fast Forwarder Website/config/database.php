<?php
$hostname = "localhost";
$username = "root";
$password = "";
$databasename = ""; //ENTER DATABASE Name

$conn = new mysqli($hostname, $username, $password, $databasename);

//CHECK CONNECTION STATUS
if ($conn->connect_error)
{
  die("CONNECTION FAILED: " . $conn->connect_error);
}
?>
